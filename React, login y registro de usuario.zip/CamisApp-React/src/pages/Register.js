import React, { useState } from 'react';

export default function Register() {
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const handleSubmit = async (e)=>{
    e.preventDefault();
    alert('Simulando registro con email: '+email);
    // Aquí se puede llamar API POST /register
  };
  return (
    <div style={{padding:'2rem'}}>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email:</label><br/>
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        </div>
        <div>
          <label>Password:</label><br/>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        </div>
        <button type="submit" style={{marginTop:'1rem'}}>Register</button>
      </form>
    </div>
  );
}
