import React, { useEffect, useState } from 'react';

export default function Resultados() {
  const [products,setProducts] = useState([]);

  useEffect(()=>{
    fetch('/api/products')
      .then(res=>res.json())
      .then(data=>setProducts(data))
      .catch(err=>console.error(err));
  },[]);

  return (
    <div style={{padding:'2rem'}}>
      <h2>Resultados (React + API)</h2>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(200px,1fr))', gap:'1rem'}}>
        {products.map(p=>(
          <div key={p.id} style={{padding:'1rem', background:'white', borderRadius:'8px', boxShadow:'0 1px 6px rgba(0,0,0,0.1)'}}>
            <h4>{p.name}</h4>
            <p>Tallas: {p.size.join(', ')}</p>
            <p>₡ {p.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
