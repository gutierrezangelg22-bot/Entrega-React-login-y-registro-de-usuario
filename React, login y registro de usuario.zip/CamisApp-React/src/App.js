import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Resultados from './pages/Resultados';

export default function App() {
  return (
    <div>
      <nav style={{padding:'1rem', background:'#0b74ff', color:'white'}}>
        <Link to="/" style={{marginRight:'1rem', color:'white'}}>Home</Link>
        <Link to="/resultados" style={{marginRight:'1rem', color:'white'}}>Resultados</Link>
        <Link to="/login" style={{marginRight:'1rem', color:'white'}}>Login</Link>
        <Link to="/register" style={{color:'white'}}>Register</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/resultados" element={<Resultados />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  );
}
